/*Task 4 :-Implement a number guessing game. Generate a random number and 
prompt the user to guess the number. Provide hints such as "higher"
 or "lower" to help the user narrow down the guess.Continue until the
  user guesses the correct number.*/

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    int number, guess, attempts = 0;
    srand(time(0));
    number = rand() % 100 + 1; // Random number between 1 and 100

    do {
        cout << "Guess the number (1 to 100): ";
        cin >> guess;
        attempts++;
        if (guess > number) {
            cout << "Lower number please!" << endl;
        } else if (guess < number) {
            cout << "Higher number please!" << endl;
        } else {
            cout << "You guessed it in " << attempts << " attempts!" << endl;
        }
    } while (guess != number);

    return 0;
}
