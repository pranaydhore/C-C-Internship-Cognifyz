/* Task 5:-Write a program that copies the
contents of one file to another. Prompt
the user to input the names of the
source and destination files. Read the
contents of the source file and write
them to the destination file. */

#include <stdio.h>

void copyFile(char *source, char *destination) {
    FILE *srcFile, *destFile;
    char ch;

    srcFile = fopen(source, "r");
    if (srcFile == NULL) {
        printf("Cannot open source file.\n");
        return;
    }

    destFile = fopen(destination, "w");
    if (destFile == NULL) {
        printf("Cannot open destination file.\n");
        fclose(srcFile);
        return;
    }

    while ((ch = fgetc(srcFile)) != EOF) {
        fputc(ch, destFile);
    }

    printf("File copied successfully.\n");

    fclose(srcFile);
    fclose(destFile);
}

int main() {
    char source[100], destination[100];
    printf("Enter source file name: ");
    scanf("%s", source);
    printf("Enter destination file name: ");
    scanf("%s", destination);
    copyFile(source, destination);
    return 0;
}
