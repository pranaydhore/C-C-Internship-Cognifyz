/*Task :- Write a program that checks whether a
given word or phrase is a palindrome. A
palindrome is a word or phrase that reads
the same forwards and backwards.
Prompt the user to input a word or
phrase and display whether it is a
palindrome or not. */


#include <stdio.h>
#include <string.h>
#include <ctype.h>

int isPalindrome(char str[]) {
    int l = 0;
    int h = strlen(str) - 1;

    while (h > l) {
        if (tolower(str[l++]) != tolower(str[h--])) {
            return 0;
        }
    }
    return 1;
}

int main() {
    char str[100];
    printf("Enter a word or phrase: ");
    gets(str);

    if (isPalindrome(str)) {
        printf("The word or phrase is a palindrome.\n");
    } else {
        printf("The word or phrase is not a palindrome.\n");
    }
    return 0;
}
