/*Task :-Implement a simple rock-paperscissors game. Prompt the user to choose either
rock, paper, or scissors, and generate a random
choice for the computer. Determine the winner
based on the game rules and display the result.*/

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    string choices[] = {"Rock", "Paper", "Scissors"};
    int userChoice, computerChoice;
    srand(time(0));

    cout << "Enter your choice (0: Rock, 1: Paper, 2: Scissors): ";
    cin >> userChoice;

    computerChoice = rand() % 3;
    cout << "Computer chose: " << choices[computerChoice] << endl;

    if (userChoice == computerChoice) {
        cout << "It's a tie!" << endl;
    } else if ((userChoice == 0 && computerChoice == 2) || 
               (userChoice == 1 && computerChoice == 0) || 
               (userChoice == 2 && computerChoice == 1)) {
        cout << "You win!" << endl;
    } else {
        cout << "You lose!" << endl;
    }

    return 0;
}
