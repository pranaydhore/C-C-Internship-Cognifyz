/*Create a simple inventory management system
that allows users to add items, display the list of
items, and search for items by name or ID.
Implement the necessary methods to handle
these operations.*/

#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Item {
    int id;
    string name;
    int quantity;
};

void addItem(vector<Item> &items) {
    Item newItem;
    cout << "Enter item ID: ";
    cin >> newItem.id;
    cout << "Enter item name: ";
    cin >> newItem.name;
    cout << "Enter item quantity: ";
    cin >> newItem.quantity;
    items.push_back(newItem);
}

void displayItems(const vector<Item> &items) {
    cout << "Inventory:\n";
    for (const auto &item : items) {
        cout << "ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity << endl;
    }
}

void searchItem(const vector<Item> &items) {
    int id;
    cout << "Enter item ID to search: ";
    cin >> id;
    for (const auto &item : items) {
        if (item.id == id) {
            cout << "Item found - ID: " << item.id << ", Name: " << item.name << ", Quantity: " << item.quantity << endl;
            return;
        }
    }
    cout << "Item not found.\n";
}

int main() {
    vector<Item> items;
    int choice;

    while (true) {
        cout << "1. Add Item\n2. Display Items\n3. Search Item\n4. Exit\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                addItem(items);
                break;
            case 2:
                displayItems(items);
                break;
            case 3:
                searchItem(items);
                break;
            case 4:
                return 0;
            default:
                cout << "Invalid choice. Please try again.\n";
        }
    }
    return 0;
}
