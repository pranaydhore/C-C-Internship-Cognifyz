/* Task :-Create a program that calculates the
average grade of a student. Prompt the
user to enter the number of subjects,
and then input the grades for each
subject. Calculate the average grade and
display it to the user.*/

#include <iostream>
using namespace std;

int main() {
    int n;
    float grade, sum = 0.0, average;

    cout << "Enter the number of subjects: ";
    cin >> n;

    for (int i = 0; i < n; ++i) {
        cout << "Enter grade for subject " << i + 1 << ": ";
        cin >> grade;
        sum += grade;
    }

    average = sum / n;
    cout << "Average grade: " << average << endl;

    return 0;
}
