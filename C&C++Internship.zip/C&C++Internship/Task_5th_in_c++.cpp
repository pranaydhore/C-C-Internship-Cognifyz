/* Task 5:-Write a program that copies the
contents of one file to another. Prompt
the user to input the names of the
source and destination files. Read the
contents of the source file and write
them to the destination file. */


#include <iostream>
#include <fstream>
using namespace std;

void copyFile(const string &source, const string &destination) {
    ifstream srcFile(source, ios::binary);
    ofstream destFile(destination, ios::binary);

    if (!srcFile) {
        cout << "Cannot open source file." << endl;
        return;
    }

    if (!destFile) {
        cout << "Cannot open destination file." << endl;
        return;
    }

    destFile << srcFile.rdbuf();

    cout << "File copied successfully." << endl;
}

int main() {
    string source, destination;
    cout << "Enter source file name: ";
    cin >> source;
    cout << "Enter destination file name: ";
    cin >> destination;
    copyFile(source, destination);
    return 0;
}
