/* Task :-Create a simple inventory management system
that allows users to add items, display the list of
items, and search for items by name or ID.
Implement the necessary methods to handle
these operations.*/


#include <stdio.h>
#include <string.h>

struct Item {
    int id;
    char name[50];
    int quantity;
};

void addItem(struct Item items[], int *count) {
    printf("Enter item ID: ");
    scanf("%d", &items[*count].id);
    printf("Enter item name: ");
    scanf("%s", items[*count].name);
    printf("Enter item quantity: ");
    scanf("%d", &items[*count].quantity);
    (*count)++;
}

void displayItems(struct Item items[], int count) {
    printf("Inventory:\n");
    for (int i = 0; i < count; i++) {
        printf("ID: %d, Name: %s, Quantity: %d\n", items[i].id, items[i].name, items[i].quantity);
    }
}

void searchItem(struct Item items[], int count) {
    int id;
    printf("Enter item ID to search: ");
    scanf("%d", &id);
    for (int i = 0; i < count; i++) {
        if (items[i].id == id) {
            printf("Item found - ID: %d, Name: %s, Quantity: %d\n", items[i].id, items[i].name, items[i].quantity);
            return;
        }
    }
    printf("Item not found.\n");
}

int main() {
    struct Item items[100];
    int count = 0, choice;

    while (1) {
        printf("1. Add Item\n2. Display Items\n3. Search Item\n4. Exit\nEnter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addItem(items, &count);
                break;
            case 2:
                displayItems(items, count);
                break;
            case 3:
                searchItem(items, count);
                break;
            case 4:
                return 0;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
    return 0;
}


