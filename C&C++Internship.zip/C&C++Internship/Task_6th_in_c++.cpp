/*Task :-Write a program that checks whether a
given word or phrase is a palindrome. A
palindrome is a word or phrase that reads
the same forwards and backwards.
Prompt the user to input a word or
phrase and display whether it is a
palindrome or not.*/

#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

bool isPalindrome(string str) {
    transform(str.begin(), str.end(), str.begin(), ::tolower);
    int l = 0;
    int h = str.length() - 1;

    while (h > l) {
        if (str[l++] != str[h--]) {
            return false;
        }
    }
    return true;
}

int main() {
    string str;
    cout << "Enter a word or phrase: ";
    getline(cin, str);

    if (isPalindrome(str)) {
        cout << "The word or phrase is a palindrome." << endl;
    } else {
        cout << "The word or phrase is not a palindrome." << endl;
    }
    return 0;
}
