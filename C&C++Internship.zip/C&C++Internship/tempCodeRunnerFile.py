
for radius in range(40,200,40):
    pen.penup()
    pen.goto(0,-radius)
    pen.setheading(0)
    pen.pendown()
    pen.circle(radius)


pen.penup()
pen.goto(0,-50)
pen.color('black')
pen.pendown()
pen.begin_fill()
pen.circle(40)
pen.end_fill()



pen.width(3)
angles=[45,90,135,180,255,270,315,360]
leg_length=100


for angle in angles:
    draw_line(0,-50,angle,leg_length)

