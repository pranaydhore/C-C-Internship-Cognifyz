/*Write a program that sorts an array of
integers in ascending or descending
order. Prompt the user to input the array
elements and choose the sorting order.
Display the sorted array.*/

#include <iostream>
#include <vector>
using namespace std;

void bubbleSort(vector<int> &arr, bool ascending) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if ((ascending && arr[j] > arr[j + 1]) || (!ascending && arr[j] < arr[j + 1])) {
                swap(arr[j], arr[j + 1]);
            }
        }
    }
}

int main() {
    int n, order;
    cout << "Enter number of elements: ";
    cin >> n;
    vector<int> arr(n);
    cout << "Enter the elements: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }
    cout << "Enter 1 for ascending or 0 for descending order: ";
    cin >> order;

    bubbleSort(arr, order);

    cout << "Sorted array: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}
