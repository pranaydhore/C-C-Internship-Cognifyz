/*Task :- Create a program that calculates the
average grade of a student. Prompt the
user to enter the number of subjects,
and then input the grades for each
subject. Calculate the average grade and
display it to the user. */


#include <stdio.h>

int main() {
    int n;
    float grade, sum = 0.0, average;

    printf("Enter the number of subjects: ");
    scanf("%d", &n);

    for (int i = 0; i < n; ++i) {
        printf("Enter grade for subject %d: ", i + 1);
        scanf("%f", &grade);
        sum += grade;
    }

    average = sum / n;
    printf("Average grade: %.2f\n", average);

    return 0;
}
