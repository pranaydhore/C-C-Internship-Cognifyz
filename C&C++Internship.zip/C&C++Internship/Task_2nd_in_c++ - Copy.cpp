/*Task 2 :-Write a program that takes two numbers and an operator 
as input(+,-,*,/,%)and performs the corresponding arithmetic 
operation.Displaytheresultontheconsole.*/

#include <iostream>
using namespace std;

int main() {
    char op;
    double num1, num2;
    cout << "Enter an operator (+, -, *, /, %): ";
    cin >> op;
    cout << "Enter two operands: ";
    cin >> num1 >> num2;

    switch (op) {
        case '+':
            cout << num1 << " + " << num2 << " = " << num1 + num2 << endl;
            break;
        case '-':
            cout << num1 << " - " << num2 << " = " << num1 - num2 << endl;
            break;
        case '*':
            cout << num1 << " * " << num2 << " = " << num1 * num2 << endl;
            break;
        case '/':
            if (num2 != 0)
                cout << num1 << " / " << num2 << " = " << num1 / num2 << endl;
            else
                cout << "Division by zero error!" << endl;
            break;
        case '%':
            if ((int)num2 != 0)
                cout << (int)num1 << " % " << (int)num2 << " = " << (int)num1 % (int)num2 << endl;
            else
                cout << "Division by zero error!" << endl;
            break;
        default:
            cout << "Invalid operator" << endl;
    }
    return 0;
}
