/*Implement a program that generates the Fibonacci series up to a given 
number of terms.Prompt the user to enter the number of terms and display 
the series.*/


#include <iostream>
using namespace std;

void generateFibonacci(int n) {
    int t1 = 0, t2 = 1, nextTerm;
    cout << "Fibonacci Series: " << t1 << ", " << t2;
    for (int i = 3; i <= n; ++i) {
        nextTerm = t1 + t2;
        cout << ", " << nextTerm;
        t1 = t2;
        t2 = nextTerm;
    }
    cout << endl;
}

int main() {
    int n;
    cout << "Enter the number of terms: ";
    cin >> n;
    generateFibonacci(n);
    return 0;
}
