/*Task :-Implement a simple rock-paperscissors game. Prompt the user to choose either
rock, paper, or scissors, and generate a random
choice for the computer. Determine the winner
based on the game rules and display the result. */


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    char *choices[] = {"Rock", "Paper", "Scissors"};
    int userChoice, computerChoice;
    srand(time(0));

    printf("Enter your choice (0: Rock, 1: Paper, 2: Scissors): ");
    scanf("%d", &userChoice);

    computerChoice = rand() % 3;
    printf("Computer chose: %s\n", choices[computerChoice]);

    if (userChoice == computerChoice) {
        printf("It's a tie!\n");
    } else if ((userChoice == 0 && computerChoice == 2) || 
               (userChoice == 1 && computerChoice == 0) || 
               (userChoice == 2 && computerChoice == 1)) {
        printf("You win!\n");
    } else {
        printf("You lose!\n");
    }

    return 0;
}
