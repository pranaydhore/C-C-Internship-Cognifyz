#include<iostream>
// using namespace std;
// int factorial(int n) {
//     int fact=1;
//     for(int i=1;i<=n;i++) {
//         fact*=i;
//         cout<<"factorial ="<<fact<<endl;
//     }
//     return fact;
// }
// int main() {
   
//     cout<<factorial(4);
// }